
public interface IAnimal {
  boolean isNormalSize () ;
}