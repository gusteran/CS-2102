
public interface ISet {

	ISet addElt(String guest);
	boolean hasElt(String guest);
	int size();
}
