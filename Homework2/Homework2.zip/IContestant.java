
public interface IContestant {
//	public boolean expectToBeat(IContestant opponent);
}
