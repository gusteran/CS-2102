class Main {
  
  public static void main(String[] args) {
    Examples test = new Examples();
    test.checkHBLen();
//	  System.out.println("This doesn't do anything on its own. Run your tests.");
  }
}