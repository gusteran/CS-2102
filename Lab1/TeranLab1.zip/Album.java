
public class Album {
	String name;
	
	public Album(String albumName) {
		name = albumName;
	}
}
